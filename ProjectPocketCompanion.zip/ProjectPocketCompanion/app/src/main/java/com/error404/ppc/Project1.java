package com.error404.ppc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Project1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project1);
    }
}
